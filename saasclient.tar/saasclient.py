#!/usr/bin/python 
import commands,os 
commands.getstatusoutput('ssh -X  root@192.168.2.20 gedit ') 
